package app.maarid.gallery

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Full-screen video player that lives inside the app.
 * Play / pause, a seek bar, 10 seconds back and forward, and previous / next video.
 */
class VideoPlayerActivity : Activity() {

    private lateinit var video: VideoView
    private lateinit var titleView: TextView
    private lateinit var counterView: TextView
    private lateinit var seek: SeekBar
    private lateinit var curView: TextView
    private lateinit var durView: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var prevBtn: ImageButton
    private lateinit var nextBtn: ImageButton
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var errorBox: View

    private var ready = false
    private var ids = LongArray(0)
    private var names: Array<String> = emptyArray()
    private var index = 0
    private var dragging = false

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            val d = video.duration
            if (!dragging && d > 0) {
                val p = video.currentPosition
                seek.progress = p
                curView.text = fmt(p)
            }
            try { refreshPlayIcon() } catch (e: Throwable) { }
            handler.postDelayed(this, 400)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        CrashLog.install(this)
        ids = intent.getLongArrayExtra("ids") ?: LongArray(0)
        names = intent.getStringArrayExtra("names") ?: emptyArray()
        if (ids.isEmpty()) {
            finish()
            return
        }
        index = intent.getIntExtra("index", 0).coerceIn(0, ids.size - 1)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            buildUi()
            ready = true
            load(index)
            handler.post(ticker)
        } catch (e: Throwable) {
            CrashLog.save(this, e)
            android.widget.Toast.makeText(this, "تعذّر فتح المشغّل", android.widget.Toast.LENGTH_LONG).show()
            finish()
            return
        }
        try {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (e: Throwable) {
        }
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun iconButton(res: Int, size: Int = 52, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setBackgroundColor(Color.TRANSPARENT)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(dp(12), dp(12), dp(12), dp(12))
        b.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun labeled(res: Int, label: String, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.addView(iconButton(res, 52, onClick))
        val t = TextView(this)
        t.text = label
        t.setTextColor(0xFFCCCCCC.toInt())
        t.textSize = 11f
        t.gravity = Gravity.CENTER
        box.addView(t, LinearLayout.LayoutParams(WRAP, WRAP))
        return box
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR

        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))

        // top bar: close, name, counter
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(28), dp(16), dp(8))
        top.setBackgroundColor(0x99000000.toInt())
        top.addView(iconButton(R.drawable.ic_close, 52) { finish() })
        titleView = TextView(this)
        titleView.setTextColor(Color.WHITE)
        titleView.textSize = 15f
        titleView.maxLines = 1
        titleView.ellipsize = TextUtils.TruncateAt.END
        top.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        counterView = TextView(this)
        counterView.setTextColor(0xFFCCCCCC.toInt())
        counterView.textSize = 13f
        top.addView(counterView, LinearLayout.LayoutParams(WRAP, WRAP))
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        topBar = top

        // bottom bar: time + seek bar, then the buttons
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setPadding(dp(16), dp(12), dp(16), dp(24))
        bottom.setBackgroundColor(0x99000000.toInt())

        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        timeRow.gravity = Gravity.CENTER_VERTICAL
        curView = TextView(this)
        curView.setTextColor(Color.WHITE)
        curView.textSize = 13f
        curView.text = "0:00"
        durView = TextView(this)
        durView.setTextColor(Color.WHITE)
        durView.textSize = 13f
        durView.text = "0:00"
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) curView.text = fmt(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                video.seekTo(seekBar?.progress ?: 0)
                dragging = false
            }
        })
        timeRow.addView(curView, LinearLayout.LayoutParams(WRAP, WRAP))
        timeRow.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        timeRow.addView(durView, LinearLayout.LayoutParams(WRAP, WRAP))
        bottom.addView(timeRow, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        prevBtn = iconButton(R.drawable.ic_prev, 52) { if (index > 0) load(index - 1) }
        playBtn = iconButton(R.drawable.ic_play, 68) { togglePlay() }
        nextBtn = iconButton(R.drawable.ic_next, 52) { if (index < ids.size - 1) load(index + 1) }
        row.addView(prevBtn)
        row.addView(labeled(R.drawable.ic_rew, "10 ث") { seekBy(-10000) })
        row.addView(playBtn)
        row.addView(labeled(R.drawable.ic_fwd, "10 ث") { seekBy(10000) })
        row.addView(nextBtn)
        bottom.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        bottomBar = bottom

        // shown when this phone cannot play a file
        val err = LinearLayout(this)
        err.orientation = LinearLayout.VERTICAL
        err.gravity = Gravity.CENTER
        err.setPadding(dp(24), dp(24), dp(24), dp(24))
        err.visibility = View.GONE
        val errText = TextView(this)
        errText.text = "تعذّر تشغيل هذا الفيديو داخل المعرض."
        errText.setTextColor(Color.WHITE)
        errText.textSize = 15f
        errText.gravity = Gravity.CENTER
        val errBtn = Button(this)
        errBtn.text = "فتح في مشغّل آخر"
        errBtn.setOnClickListener { openExternal() }
        err.addView(errText, LinearLayout.LayoutParams(WRAP, WRAP))
        err.addView(errBtn, LinearLayout.LayoutParams(WRAP, WRAP))
        root.addView(err, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        errorBox = err

        root.setOnClickListener { toggleControls() }

        video.setOnPreparedListener { mp ->
            seek.max = mp.duration
            durView.text = fmt(mp.duration)
            errorBox.visibility = View.GONE
            video.start()
            refreshPlayIcon()
        }
        video.setOnCompletionListener {
            refreshPlayIcon()
            showControls()
        }
        video.setOnErrorListener { _, _, _ ->
            errorBox.visibility = View.VISIBLE
            refreshPlayIcon()
            showControls()
            true
        }

        setContentView(root)
    }

    // ------------------------------------------------------------------ playback

    private fun load(i: Int) {
        index = i
        titleView.text = if (i < names.size) names[i] else ""
        counterView.text = "${i + 1} / ${ids.size}"
        prevBtn.alpha = if (i > 0) 1f else 0.35f
        nextBtn.alpha = if (i < ids.size - 1) 1f else 0.35f
        errorBox.visibility = View.GONE
        seek.progress = 0
        curView.text = "0:00"
        durView.text = "0:00"
        try {
            video.setVideoURI(ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, ids[i]))
        } catch (e: Throwable) {
            errorBox.visibility = View.VISIBLE
        }
    }

    private fun togglePlay() {
        if (video.isPlaying) video.pause() else video.start()
        refreshPlayIcon()
    }

    private fun seekBy(deltaMs: Int) {
        val d = video.duration
        if (d <= 0) return
        video.seekTo((video.currentPosition + deltaMs).coerceIn(0, d))
    }

    private fun refreshPlayIcon() {
        playBtn.setImageResource(if (video.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun showControls() {
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
    }

    private fun toggleControls() {
        val v = if (bottomBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        topBar.visibility = v
        bottomBar.visibility = v
    }

    private fun openExternal() {
        try {
            val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, ids[index])
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "video/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            // no other player installed
        }
    }

    private fun fmt(ms: Int): String {
        val s = ms / 1000
        return if (s >= 3600) {
            String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        } else {
            String.format(Locale.US, "%d:%02d", s / 60, s % 60)
        }
    }

    override fun onPause() {
        super.onPause()
        if (!ready) return
        try { video.pause() } catch (e: Throwable) { }
        refreshPlayIcon()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (ready) try { video.stopPlayback() } catch (e: Throwable) { }
        super.onDestroy()
    }
}
