package app.maarid.gallery

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Saves the reason of a crash to a file so the next launch can show it. */
object CrashLog {
    private fun file(c: Context) = File(c.filesDir, "crash.txt")

    fun install(c: Context) {
        val app = c.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        if (old is Handler) return
        Thread.setDefaultUncaughtExceptionHandler(Handler(app, old))
    }

    fun save(c: Context, e: Throwable) {
        try {
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            file(c.applicationContext).writeText(sw.toString().take(1500))
        } catch (x: Throwable) {
        }
    }

    fun take(c: Context): String? {
        val f = file(c)
        if (!f.exists()) return null
        val t = try { f.readText() } catch (x: Throwable) { null }
        f.delete()
        return t
    }

    private class Handler(
        val c: Context,
        val old: Thread.UncaughtExceptionHandler?
    ) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            save(c, e)
            old?.uncaughtException(t, e)
        }
    }
}
