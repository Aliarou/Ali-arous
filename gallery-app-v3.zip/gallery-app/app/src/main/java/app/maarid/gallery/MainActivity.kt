package app.maarid.gallery

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.AssetFileDescriptor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.nio.channels.Channels

/**
 * Hosts the gallery page (assets/index.html) in a WebView and gives it three things:
 *  - the media permission request,
 *  - the list of photos and videos on the phone (MediaStore),
 *  - the bytes of each photo, video and thumbnail, served from the page's own origin.
 */
class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var pendingDelete: List<String> = emptyList()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            callJs("window.onNativePermission && window.onNativePermission()")
        }

    private val deleteLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val ids = JSONArray(pendingDelete).toString()
                callJs("window.onNativeDeleted && window.onNativeDeleted($ids)")
            } else {
                callJs("window.onNativeDeleteCancelled && window.onNativeDeleteCancelled()")
            }
            pendingDelete = emptyList()
        }

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.setBackgroundColor(ContextCompat.getColor(this, R.color.window_bg))
        // The page handles long-press itself (multi-select), so turn off the system's own long-press behaviour.
        web.isLongClickable = false
        web.setOnLongClickListener { true }
        web.isHapticFeedbackEnabled = false
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.addJavascriptInterface(Bridge(), "Native")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url
                if (url.host == WebViewAssetLoader.DEFAULT_DOMAIN) {
                    val path = url.path ?: ""
                    if (path.startsWith("/media/")) return serveMedia(request, path)
                    if (path.startsWith("/thumb/")) return serveThumb(url, path)
                }
                return assetLoader.shouldInterceptRequest(url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript(
                    "(window.onNativeBack && window.onNativeBack()) === true"
                ) { handled ->
                    if (handled != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")

        // Ask for access as soon as the app opens.
        if (!hasPerm()) requestPerm()
    }

    override fun onResume() {
        super.onResume()
        callJs("window.onNativeResume && window.onNativeResume()")
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- permissions

    private fun perms(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO
        )
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasPerm(): Boolean = perms().any { granted(it) }

    private fun requestPerm() = permissionLauncher.launch(perms())

    // ---------------------------------------------------------------- JS bridge

    inner class Bridge {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasPerm()

        @JavascriptInterface
        fun requestPermission() {
            runOnUiThread { requestPerm() }
        }

        @JavascriptInterface
        fun openSettings() {
            runOnUiThread {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", packageName, null)
                    )
                )
            }
        }

        @JavascriptInterface
        fun listMedia(): String = if (hasPerm()) queryMedia().toString() else "[]"

        @JavascriptInterface
        fun requestDelete(idsJson: String) {
            runOnUiThread { startDelete(idsJson) }
        }

        @JavascriptInterface
        fun openVideo(idStr: String) {
            runOnUiThread { openInPlayer(idStr) }
        }

        /** Opens the app's own player: json = {"ids":[...],"names":[...],"index":n} */
        @JavascriptInterface
        fun playVideo(json: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(json)
                    val idsArr = o.getJSONArray("ids")
                    val namesArr = o.getJSONArray("names")
                    val ids = LongArray(idsArr.length()) { idsArr.getLong(it) }
                    val names = Array(namesArr.length()) { namesArr.getString(it) }
                    startActivity(
                        Intent(this@MainActivity, VideoPlayerActivity::class.java)
                            .putExtra("ids", ids)
                            .putExtra("names", names)
                            .putExtra("index", o.optInt("index", 0))
                    )
                } catch (e: Exception) {
                    callJs("window.onNativeToast && window.onNativeToast('تعذّر فتح مشغّل الفيديو')")
                }
            }
        }
    }

    private fun callJs(js: String) {
        runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(js, null) }
    }

    // ---------------------------------------------------------------- MediaStore

    private fun queryMedia(): JSONArray {
        val out = JSONArray()

        contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED
            ),
            null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val iDate = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.put(
                    JSONObject()
                        .put("id", "p$id")
                        .put("nid", id)
                        .put("kind", "photo")
                        .put("name", c.getString(iName) ?: "")
                        .put("added", c.getLong(iDate) * 1000L)
                        .put("duration", 0)
                )
            }
        }

        contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.DURATION
            ),
            null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iDate = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.put(
                    JSONObject()
                        .put("id", "v$id")
                        .put("nid", id)
                        .put("kind", "video")
                        .put("name", c.getString(iName) ?: "")
                        .put("added", c.getLong(iDate) * 1000L)
                        .put("duration", c.getLong(iDur) / 1000L)
                )
            }
        }
        return out
    }

    private fun contentUri(kind: String, id: Long): Uri = ContentUris.withAppendedId(
        if (kind == "video") MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        id
    )

    // ---------------------------------------------------------------- serving files to the page

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )

    /** /thumb/{photo|video}/{id}?s=size  ->  small JPEG */
    private fun serveThumb(url: Uri, path: String): WebResourceResponse {
        val parts = path.removePrefix("/thumb/").split("/")
        if (parts.size != 2) return notFound()
        val id = parts[1].toLongOrNull() ?: return notFound()
        val size = (url.getQueryParameter("s")?.toIntOrNull() ?: 360).coerceIn(96, 2048)
        return try {
            val bmp = contentResolver.loadThumbnail(contentUri(parts[0], id), Size(size, size), null)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
            WebResourceResponse(
                "image/jpeg", null, 200, "OK",
                mapOf("Cache-Control" to "max-age=86400"),
                ByteArrayInputStream(bos.toByteArray())
            )
        } catch (e: Exception) {
            notFound()
        }
    }

    /** /media/{photo|video}/{id}  ->  the original file, with Range support so videos can seek */
    private fun serveMedia(request: WebResourceRequest, path: String): WebResourceResponse {
        val parts = path.removePrefix("/media/").split("/")
        if (parts.size != 2) return notFound()
        val id = parts[1].toLongOrNull() ?: return notFound()
        val uri = contentUri(parts[0], id)
        return try {
            val afd = contentResolver.openAssetFileDescriptor(uri, "r") ?: return notFound()
            val total = afd.length
            val mime = contentResolver.getType(uri)
                ?: if (parts[0] == "video") "video/mp4" else "image/jpeg"
            val headers = hashMapOf("Accept-Ranges" to "bytes", "Cache-Control" to "max-age=3600")

            var start = 0L
            var end = total - 1
            var partial = false
            val range = request.requestHeaders["Range"]
            if (range != null && range.startsWith("bytes=") && total > 0) {
                val spec = range.removePrefix("bytes=").split(",")[0].trim()
                val dash = spec.indexOf('-')
                if (dash >= 0) {
                    val a = spec.substring(0, dash)
                    val b = spec.substring(dash + 1)
                    if (a.isEmpty()) {
                        val n = b.toLongOrNull() ?: total
                        start = (total - n).coerceAtLeast(0L)
                        end = total - 1
                    } else {
                        start = a.toLongOrNull() ?: 0L
                        end = b.toLongOrNull() ?: (total - 1)
                    }
                    if (end > total - 1) end = total - 1
                    if (start > end) {
                        afd.close()
                        headers["Content-Range"] = "bytes */$total"
                        return WebResourceResponse(
                            mime, null, 416, "Range Not Satisfiable", headers,
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                    partial = true
                }
            }

            val fis = FileInputStream(afd.fileDescriptor)
            fis.channel.position(afd.startOffset + start)
            val length = if (total > 0) end - start + 1 else -1L
            val body: InputStream =
                if (length >= 0) LimitedStream(Channels.newInputStream(fis.channel), length, afd)
                else fis
            if (length >= 0) headers["Content-Length"] = length.toString()

            if (partial) {
                headers["Content-Range"] = "bytes $start-$end/$total"
                WebResourceResponse(mime, null, 206, "Partial Content", headers, body)
            } else {
                WebResourceResponse(mime, null, 200, "OK", headers, body)
            }
        } catch (e: Exception) {
            notFound()
        }
    }

    private class LimitedStream(
        input: InputStream,
        private var remaining: Long,
        private val afd: AssetFileDescriptor
    ) : FilterInputStream(input) {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = super.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = super.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun close() {
            try {
                super.close()
            } finally {
                afd.close()
            }
        }
    }

    // ---------------------------------------------------------------- deleting from the phone

    /** Opens a video in the phone's own video player (used when the in-app player cannot play it). */
    private fun openInPlayer(idStr: String) {
        val id = idStr.toLongOrNull() ?: return
        try {
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(contentUri("video", id), "video/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: Exception) {
            callJs("window.onNativeToast && window.onNativeToast('لا يوجد مشغّل فيديو متاح')")
        }
    }

    /** Asks Android to delete the files. The system shows its own confirmation dialog. */
    private fun startDelete(idsJson: String) {
        try {
            val arr = JSONArray(idsJson)
            val uris = ArrayList<Uri>()
            val ids = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val id = arr.getString(i)
                val num = id.substring(1).toLongOrNull() ?: continue
                uris.add(contentUri(if (id.startsWith("v")) "video" else "photo", num))
                ids.add(id)
            }
            if (uris.isEmpty()) return
            pendingDelete = ids
            val pi = MediaStore.createDeleteRequest(contentResolver, uris)
            deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } catch (e: Exception) {
            callJs("window.onNativeDeleteCancelled && window.onNativeDeleteCancelled()")
        }
    }
}
